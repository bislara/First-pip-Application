import setuptools

setuptools.setup(
     name='wthr',  
     version='0.1',
     scripts=['weather_info']
 )


